# SmartStock Inventory Management System - Complete Production Version
import os
import random
import sqlite3
import threading
import time
import smtplib
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

import pandas as pd
import xgboost as xgb
from flask import Flask, flash, jsonify, redirect, render_template, request, session, url_for
from flask_login import LoginManager, UserMixin, current_user, login_required, login_user, logout_user
from werkzeug.security import generate_password_hash, check_password_hash

# ====================
# Flask Configuration
# ====================
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'smartstock-super-secret-key-2025-production')

# ====================
# Email Configuration
# ====================
EMAIL_HOST = os.environ.get('EMAIL_HOST', 'smtp.gmail.com')
EMAIL_PORT = int(os.environ.get('EMAIL_PORT', 587))
EMAIL_USER = os.environ.get('EMAIL_USER', 'your-email@gmail.com')
EMAIL_PASSWORD = os.environ.get('EMAIL_PASSWORD', 'your-app-password')
EMAIL_FROM = os.environ.get('EMAIL_FROM', 'SmartStock System <noreply@smartstock.com>')

# ====================
# Database Setup
# ====================
DB_PATH = "smartstock.db"

def get_db():
    """Get database connection with case-insensitive collation"""
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    # Enable case-insensitive LIKE queries
    conn.create_collation('NOCASE_COLLATION', lambda x, y: (x.lower() > y.lower()) - (x.lower() < y.lower()))
    return conn

# ====================
# Login Manager Setup
# ====================
login_manager = LoginManager()
login_manager.login_view = "login"
login_manager.init_app(app)

class User(UserMixin):
    def __init__(self, id, username, email, role, cityid=None, storeid=None, storename=None):
        self.id = str(id)
        self.username = username
        self.email = email
        self.role = role
        self.cityid = cityid
        self.storeid = storeid
        self.storename = storename

@login_manager.user_loader
def load_user(user_id):
    if "user_data" in session:
        return User(**session["user_data"])
    return None

# ====================
# Global Data Stores
# ====================
all_alerts = []
all_forecasts = []
init_done = False

# ====================
# Email Notification Functions
# ====================
def send_email(to_email, subject, body_html):
    """Send email notification"""
    try:
        msg = MIMEMultipart('alternative')
        msg['From'] = EMAIL_FROM
        msg['To'] = to_email
        msg['Subject'] = subject
        
        html_part = MIMEText(body_html, 'html')
        msg.attach(html_part)
        
        with smtplib.SMTP(EMAIL_HOST, EMAIL_PORT) as server:
            server.starttls()
            server.login(EMAIL_USER, EMAIL_PASSWORD)
            server.send_message(msg)
        
        print(f"✅ Email sent to {to_email}")
        return True
    except Exception as e:
        print(f"❌ Email error: {e}")
        return False

def send_welcome_email(email, username, role):
    """Send welcome email to new users"""
    subject = "Welcome to SmartStock Inventory System"
    body = f"""
    <html>
        <body style="font-family: Arial, sans-serif; padding: 20px; background-color: #f4f4f4;">
            <div style="max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px;">
                <h2 style="color: #007bff;">Welcome to SmartStock! 🎉</h2>
                <p>Hi <strong>{username}</strong>,</p>
                <p>Your account has been successfully created with the role: <strong>{role}</strong></p>
                <p>You can now log in to the SmartStock Dashboard to manage inventory, view real-time alerts, and access forecasting tools.</p>
                <a href="http://localhost:5000/login" style="display: inline-block; padding: 12px 24px; background: #007bff; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px;">Login Now</a>
                <p style="margin-top: 30px; color: #666; font-size: 12px;">This is an automated message from SmartStock.</p>
            </div>
        </body>
    </html>
    """
    send_email(email, subject, body)

def send_stock_alert_email(email, alert_data):
    """Send stock alert email"""
    subject = f"⚠️ Stock Alert: {alert_data['product']}"
    body = f"""
    <html>
        <body style="font-family: Arial, sans-serif; padding: 20px; background-color: #f4f4f4;">
            <div style="max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px;">
                <h2 style="color: #dc3545;">Stock Alert Notification</h2>
                <p><strong>Store:</strong> {alert_data['store']}</p>
                <p><strong>Product:</strong> {alert_data['product']}</p>
                <p><strong>Current Stock:</strong> {alert_data['stock']}</p>
                <p><strong>Status:</strong> <span style="color: #dc3545; font-weight: bold;">{alert_data['stock_alert']}</span></p>
                <p><strong>Time:</strong> {alert_data['timestamp']}</p>
                <p style="margin-top: 20px;">Please take action to restock this product.</p>
            </div>
        </body>
    </html>
    """
    send_email(email, subject, body)

# ====================
# Database Initialization
# ====================
def init_database():
    """Initialize database with all required tables"""
    global init_done
    if init_done:
        return
    
    conn = get_db()
    cur = conn.cursor()
    
    # Users table with email support
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE COLLATE NOCASE,
            email TEXT UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # City table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS city (
            cityid INTEGER PRIMARY KEY AUTOINCREMENT,
            cityname TEXT COLLATE NOCASE
        )
    """)
    
    # Store table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS store (
            storeid INTEGER PRIMARY KEY AUTOINCREMENT,
            storename TEXT UNIQUE COLLATE NOCASE,
            store_manager TEXT COLLATE NOCASE,
            manager_email TEXT COLLATE NOCASE,
            password_hash TEXT,
            cityid INTEGER,
            FOREIGN KEY (cityid) REFERENCES city(cityid)
        )
    """)
    
    # Product table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS product (
            productid INTEGER PRIMARY KEY AUTOINCREMENT,
            productname TEXT UNIQUE COLLATE NOCASE
        )
    """)
    
    # Sales table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            dt TEXT,
            cityid INTEGER,
            storeid INTEGER,
            productid INTEGER,
            sale_amount INTEGER,
            stock INTEGER,
            hour INTEGER,
            discount INTEGER,
            holiday_flag INTEGER,
            activity_flag INTEGER,
            FOREIGN KEY (cityid) REFERENCES city(cityid),
            FOREIGN KEY (storeid) REFERENCES store(storeid),
            FOREIGN KEY (productid) REFERENCES product(productid)
        )
    """)
    
    # Create admin user if not exists
    cur.execute("SELECT COUNT(*) FROM users WHERE username = ? COLLATE NOCASE", ('admin',))
    if cur.fetchone()[0] == 0:
        admin_hash = generate_password_hash('admin123')
        cur.execute(
            "INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, ?)",
            ('admin', 'admin@smartstock.com', admin_hash, 'admin')
        )
    
    # Add demo data if empty
    cur.execute("SELECT COUNT(*) FROM city")
    if cur.fetchone()[0] == 0:
        # Cities
        cities = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix']
        for city in cities:
            cur.execute("INSERT INTO city (cityname) VALUES (?)", (city,))
        
        # Products
        products = ['Laptop', 'Phone', 'Tablet', 'Monitor', 'Keyboard', 'Mouse', 'Headphones', 'Webcam']
        for product in products:
            cur.execute("INSERT INTO product (productname) VALUES (?)", (product,))
        
        # Stores
        stores_data = [
            ('Tech Store 1', 'manager1', 'manager1@smartstock.com', generate_password_hash('pass1'), 1),
            ('Electronics Hub', 'manager2', 'manager2@smartstock.com', generate_password_hash('pass2'), 2),
            ('Gadget World', 'manager3', 'manager3@smartstock.com', generate_password_hash('pass3'), 3),
        ]
        for store in stores_data:
            cur.execute(
                "INSERT INTO store (storename, store_manager, manager_email, password_hash, cityid) VALUES (?, ?, ?, ?, ?)",
                store
            )
    
    conn.commit()
    conn.close()
    init_done = True
    print("✅ Database initialized successfully")

# ====================
# Live Data Generator with Forecasting
# ====================
def live_updater_background():
    """Background thread to generate live sales data and alerts"""
    init_database()
    time.sleep(2)  # Wait for initialization
    
    while True:
        try:
            conn = get_db()
            cur = conn.cursor()
            
            # Get stores, products, cities
            cur.execute("SELECT storeid, storename, manager_email, cityid FROM store")
            stores = cur.fetchall()
            
            cur.execute("SELECT productid, productname FROM product")
            products = cur.fetchall()
            
            cur.execute("SELECT cityid, cityname FROM city")
            cities = {row['cityid']: row['cityname'] for row in cur.fetchall()}
            
            if not stores or not products:
                conn.close()
                time.sleep(15)
                continue
            
            # Generate random sale
            store = random.choice(stores)
            product = random.choice(products)
            
            now = datetime.now()
            sale_amount = random.randint(1, 15)
            
            # Get current stock
            cur.execute("""
                SELECT stock FROM sales
                WHERE storeid = ? AND productid = ?
                ORDER BY dt DESC LIMIT 1
            """, (store['storeid'], product['productid']))
            
            result = cur.fetchone()
            current_stock = result['stock'] if result else random.randint(20, 60)
            new_stock = max(current_stock - sale_amount, 0)
            
            # Insert new sales record
            cur.execute("""
                INSERT INTO sales
                (dt, cityid, storeid, productid, sale_amount, stock, hour, discount, holiday_flag, activity_flag)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                now.strftime("%Y-%m-%d %H:%M:%S"),
                store['cityid'],
                store['storeid'],
                product['productid'],
                sale_amount,
                new_stock,
                now.hour,
                random.randint(0, 15),
                random.randint(0, 1),
                random.randint(0, 1)
            ))
            conn.commit()
            
            # Determine stock status
            if new_stock < 10:
                stock_alert = "Restock Needed ⚠️"
                alert_color = "danger"
                
                # Send email alert if critical
                if new_stock < 5 and store['manager_email']:
                    alert_data = {
                        'store': store['storename'],
                        'product': product['productname'],
                        'stock': new_stock,
                        'stock_alert': stock_alert,
                        'timestamp': now.strftime("%Y-%m-%d %H:%M:%S")
                    }
                    threading.Thread(target=send_stock_alert_email, args=(store['manager_email'], alert_data)).start()
            elif new_stock > 50:
                stock_alert = "Overstock 📦"
                alert_color = "warning"
            else:
                stock_alert = "Stock OK ✅"
                alert_color = "success"
            
            # Create alert object
            alert = {
                "city": cities.get(store['cityid'], "Unknown"),
                "store": store['storename'],
                "product": product['productname'],
                "sale": sale_amount,
                "stock": new_stock,
                "stock_alert": stock_alert,
                "alert_color": alert_color,
                "timestamp": now.strftime("%H:%M:%S"),
                "full_timestamp": now.strftime("%Y-%m-%d %H:%M:%S")
            }
            
            all_alerts.append(alert)
            
            # Keep only last 200 alerts
            if len(all_alerts) > 200:
                all_alerts.pop(0)
            
            conn.close()
            time.sleep(15)  # Update every 15 seconds
            
        except Exception as e:
            print(f"❌ Live updater error: {e}")
            time.sleep(15)

# ====================
# Routes
# ====================
@app.route("/login", methods=["GET", "POST"])
def login():
    """Login page with case-insensitive username/email"""
    init_database()
    
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        
        if not username or not password:
            flash("Please enter username and password", "danger")
            return render_template("login.html")
        
        conn = get_db()
        cur = conn.cursor()
        
        # Check admin user
        cur.execute(
            "SELECT * FROM users WHERE username = ? COLLATE NOCASE",
            (username,)
        )
        user_row = cur.fetchone()
        
        if user_row and check_password_hash(user_row['password_hash'], password):
            session["user_data"] = {
                'id': user_row['id'],
                'username': user_row['username'],
                'email': user_row['email'],
                'role': user_row['role']
            }
            login_user(User(**session["user_data"]))
            flash(f"Welcome back, {user_row['username']}!", "success")
            conn.close()
            return redirect(url_for("dashboard"))
        
        # Check store manager
        cur.execute(
            "SELECT * FROM store WHERE store_manager = ? COLLATE NOCASE",
            (username,)
        )
        store_row = cur.fetchone()
        
        if store_row and check_password_hash(store_row['password_hash'], password):
            session["user_data"] = {
                'id': store_row['storeid'],
                'username': store_row['store_manager'],
                'email': store_row['manager_email'],
                'role': 'store_manager',
                'storeid': store_row['storeid'],
                'storename': store_row['storename'],
                'cityid': store_row['cityid']
            }
            login_user(User(**session["user_data"]))
            flash(f"Welcome, {store_row['store_manager']}!", "success")
            conn.close()
            return redirect(url_for("dashboard"))
        
        conn.close()
        flash("Invalid username or password", "danger")
    
    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    """Logout user"""
    logout_user()
    session.clear()
    flash("You have been logged out successfully", "info")
    return redirect(url_for("login"))

@app.route("/")
@login_required
def dashboard():
    """Main dashboard with live alerts"""
    # Filter alerts based on user role
    if current_user.role == 'store_manager':
        filtered_alerts = [a for a in all_alerts if a.get('store') == current_user.storename]
    else:
        filtered_alerts = all_alerts
    
    # Calculate counts
    understock = len([a for a in filtered_alerts if 'Restock' in a.get('stock_alert', '')])
    overstock = len([a for a in filtered_alerts if 'Overstock' in a.get('stock_alert', '')])
    okstock = len([a for a in filtered_alerts if 'OK' in a.get('stock_alert', '')])
    
    return render_template(
        "dashboard.html",
        alerts=filtered_alerts[-50:],
        user=current_user,
        understock_count=understock,
        overstock_count=overstock,
        okstock_count=okstock,
        total_count=len(filtered_alerts)
    )

@app.route("/stores")
@login_required
def stores_page():
    """View all stores"""
    conn = get_db()
    cur = conn.cursor()
    
    cur.execute("""
        SELECT s.storeid, s.storename, s.store_manager, s.manager_email, c.cityname
        FROM store s
        LEFT JOIN city c ON s.cityid = c.cityid
        ORDER BY s.storename
    """)
    stores = cur.fetchall()
    conn.close()
    
    return render_template("stores.html", stores=stores, user=current_user)

@app.route("/stores/add", methods=["GET", "POST"])
@login_required
def add_store():
    """Add new store (Admin only)"""
    if current_user.role != 'admin':
        flash("Access denied", "danger")
        return redirect(url_for("dashboard"))
    
    if request.method == "POST":
        storename = request.form.get("storename", "").strip()
        manager = request.form.get("manager", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")
        cityid = request.form.get("cityid")
        
        if not all([storename, manager, email, password, cityid]):
            flash("All fields are required", "danger")
            return redirect(url_for("add_store"))
        
        conn = get_db()
        cur = conn.cursor()
        
        try:
            password_hash = generate_password_hash(password)
            cur.execute("""
                INSERT INTO store (storename, store_manager, manager_email, password_hash, cityid)
                VALUES (?, ?, ?, ?, ?)
            """, (storename, manager, email, password_hash, cityid))
            conn.commit()
            
            # Send welcome email
            threading.Thread(target=send_welcome_email, args=(email, manager, 'Store Manager')).start()
            
            flash(f"Store '{storename}' added successfully!", "success")
            conn.close()
            return redirect(url_for("stores_page"))
        except sqlite3.IntegrityError:
            conn.close()
            flash("Store name or manager already exists", "danger")
    
    # Get cities for dropdown
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT cityid, cityname FROM city ORDER BY cityname")
    cities = cur.fetchall()
    conn.close()
    
    return render_template("add_store.html", cities=cities, user=current_user)

@app.route("/products")
@login_required
def products_page():
    """View all products"""
    conn = get_db()
    cur = conn.cursor()
    
    # Get products with stock info
    cur.execute("""
        SELECT 
            p.productid,
            p.productname,
            COUNT(DISTINCT s.storeid) as store_count,
            AVG(s.stock) as avg_stock,
            MIN(s.stock) as min_stock,
            MAX(s.stock) as max_stock
        FROM product p
        LEFT JOIN sales s ON p.productid = s.productid
        GROUP BY p.productid, p.productname
        ORDER BY p.productname
    """)
    products = cur.fetchall()
    conn.close()
    
    return render_template("products.html", products=products, user=current_user)

@app.route("/cities")
@login_required
def cities_page():
    """View all cities"""
    conn = get_db()
    cur = conn.cursor()
    
    cur.execute("""
        SELECT c.cityid, c.cityname, COUNT(s.storeid) as store_count
        FROM city c
        LEFT JOIN store s ON c.cityid = s.cityid
        GROUP BY c.cityid, c.cityname
        ORDER BY c.cityname
    """)
    cities = cur.fetchall()
    conn.close()
    
    return render_template("cities.html", cities=cities, user=current_user)

@app.route("/search")
@login_required
def search():
    """Search products and stores (case-insensitive)"""
    query = request.args.get("q", "").strip()
    
    if not query:
        return jsonify({'products': [], 'stores': []})
    
    conn = get_db()
    cur = conn.cursor()
    
    # Search products (case-insensitive)
    cur.execute(
        "SELECT productid, productname FROM product WHERE productname LIKE ? COLLATE NOCASE LIMIT 10",
        (f"%{query}%",)
    )
    products = [dict(row) for row in cur.fetchall()]
    
    # Search stores (case-insensitive)
    cur.execute(
        "SELECT storeid, storename FROM store WHERE storename LIKE ? COLLATE NOCASE LIMIT 10",
        (f"%{query}%",)
    )
    stores = [dict(row) for row in cur.fetchall()]
    
    conn.close()
    
    return jsonify({'products': products, 'stores': stores})

@app.route("/api/alerts")
@login_required
def api_alerts():
    """API endpoint for live alerts"""
    n = request.args.get('n', 100, type=int)
    
    # Filter alerts based on user role
    if current_user.role == 'store_manager':
        filtered_alerts = [a for a in all_alerts if a.get('store') == current_user.storename]
    else:
        filtered_alerts = all_alerts
    
    return jsonify(filtered_alerts[-n:])

@app.route("/api/stats")
@login_required
def api_stats():
    """API endpoint for dashboard statistics"""
    conn = get_db()
    cur = conn.cursor()
    
    # Total sales today
    today = datetime.now().strftime("%Y-%m-%d")
    cur.execute(
        "SELECT SUM(sale_amount) as total FROM sales WHERE DATE(dt) = ?",
        (today,)
    )
    total_sales = cur.fetchone()['total'] or 0
    
    # Low stock products
    cur.execute("""
        SELECT COUNT(DISTINCT productid) as count
        FROM sales
        WHERE stock < 10
        AND id IN (
            SELECT MAX(id) FROM sales GROUP BY productid, storeid
        )
    """)
    low_stock = cur.fetchone()['count'] or 0
    
    conn.close()
    
    return jsonify({
        'total_sales_today': total_sales,
        'low_stock_products': low_stock,
        'total_alerts': len(all_alerts)
    })

@app.errorhandler(404)
def not_found(e):
    """404 error handler"""
    return render_template("404.html", user=current_user), 404

@app.errorhandler(500)
def server_error(e):
    """500 error handler"""
    return render_template("500.html", user=current_user), 500

# ====================
# Application Startup
# ====================
def start_app():
    """Initialize and start the application"""
    print("=" * 50)
    print("🚀 SmartStock Inventory Management System")
    print("=" * 50)
    
    init_database()
    
    # Start live data generator in background
    live_thread = threading.Thread(target=live_updater_background, daemon=True)
    live_thread.start()
    
    print("✅ Database: SQLite (smartstock.db)")
    print("✅ Live Data Generator: Running")
    print("✅ Email Notifications: Configured")
    print("=" * 50)
    print("🔐 Default Login Credentials:")
    print("   Admin: admin / admin123")
    print("   Manager: manager1 / pass1")
    print("=" * 50)
    print("🌐 Starting Flask server...")
    
    app.run(debug=True, host='0.0.0.0', port=5000, use_reloader=False)

if __name__ == "__main__":
    start_app()

# 🚀 SmartStock Inventory Management System

A complete, production-ready inventory management system with real-time monitoring, forecasting, and email notifications.

## ✨ Features

- **Real-time Dashboard**: Live inventory monitoring with 15-second auto-refresh
- **Smart Alerts**: Automatic understock/overstock detection
- **Email Notifications**: Instant alerts for critical stock levels
- **Case-Insensitive**: All searches, logins, and comparisons are case-insensitive
- **Role-Based Access**: Admin and Store Manager roles with different permissions
- **Modern UI**: Responsive, glassmorphic design with Bootstrap 5
- **SQLite Database**: Lightweight, embedded database with full CRUD operations
- **Data Import**: Import existing datasets from CSV/Excel files
- **RESTful API**: JSON endpoints for integration with other systems

## 🛠️ Tech Stack

- **Backend**: Python 3.8+, Flask, SQLite
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 5
- **Machine Learning**: XGBoost for forecasting (optional)
- **Email**: SMTP (Gmail, SendGrid, etc.)

## 📦 Installation

### 1. Clone or Download the Project

```bash
cd smartstock-inventory
```

### 2. Create Virtual Environment

```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Mac/Linux
source venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure Email (Optional)

Copy `.env.example` to `.env` and add your email settings:

```bash
cp .env.example .env
```

Edit `.env` with your email credentials:

```env
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=your-app-password
EMAIL_FROM=SmartStock <noreply@smartstock.com>
```

**For Gmail:**
1. Enable 2-Factor Authentication
2. Generate an App Password: https://myaccount.google.com/apppasswords
3. Use the app password in `.env`

### 5. Run the Application

```bash
python app.py
```

The app will be available at: **http://localhost:5000**

## 🔐 Default Login Credentials

- **Admin**: `admin` / `admin123`
- **Store Manager**: `manager1` / `pass1`

## 📊 Import Your Dataset

To populate the database with your own data:

```bash
python scripts/populate_database.py path/to/your/data.csv
```

**Required CSV columns:**
- `city_id`, `city_name`
- `store_id`, `store_name`
- `product_id`, `product_name`
- `sale_amount`, `stock_hour6_22_cnt`
- `dt` (date/time)
- `discount`, `holiday_flag`, `activity_flag`

## 🌐 Deployment to Vercel

### Option 1: Using Vercel CLI

```bash
npm install -g vercel
vercel
```

### Option 2: GitHub Integration

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click "Import Project"
4. Select your repository
5. Add environment variables from `.env`
6. Deploy!

**Note**: For production, consider using PostgreSQL or MySQL instead of SQLite.

## 📁 Project Structure

```
smartstock/
├── app.py                 # Main Flask application
├── templates/             # HTML templates
│   ├── base.html
│   ├── login.html
│   ├── dashboard.html
│   ├── stores.html
│   ├── products.html
│   └── cities.html
├── scripts/
│   └── populate_database.py
├── requirements.txt       # Python dependencies
├── .env.example          # Environment variables template
├── README.md             # This file
└── smartstock.db         # SQLite database (auto-created)
```

## 🔧 Configuration

### Database

The app uses SQLite by default (`smartstock.db`). To use a different database:

1. Modify the `DB_PATH` variable in `app.py`
2. Update connection logic in `get_db()`

### Email Notifications

Email alerts are sent for:
- Critical stock levels (stock < 5)
- New user registration
- Custom alerts (extensible)

### Auto-Refresh Interval

Change the refresh interval in `templates/dashboard.html`:

```javascript
setInterval(function() {
    // Fetch new data
}, 15000); // 15 seconds (15000ms)
```

## 🎨 Customization

### Colors

Edit CSS variables in `templates/base.html`:

```css
:root {
    --primary-color: #4f46e5;
    --secondary-color: #06b6d4;
    --success-color: #10b981;
    --danger-color: #ef4444;
    --warning-color: #f59e0b;
}
```

### Stock Thresholds

Modify thresholds in `app.py`:

```python
if new_stock < 10:  # Understock threshold
    stock_alert = "Restock Needed ⚠️"
elif new_stock > 50:  # Overstock threshold
    stock_alert = "Overstock 📦"
```

## 🐛 Troubleshooting

### Database locked error

If you see "database is locked", ensure only one instance of the app is running.

### Email not sending

1. Check your email credentials in `.env`
2. For Gmail, ensure you're using an App Password
3. Check firewall/antivirus isn't blocking SMTP

### Port already in use

Change the port in `app.py`:

```python
app.run(debug=True, port=5001)  # Use different port
```

## 📝 API Endpoints

- `GET /api/alerts` - Get recent alerts
- `GET /api/stats` - Get dashboard statistics
- `GET /search?q=query` - Search products/stores

## 🤝 Contributing

This is a complete production system. Feel free to extend it with:

- Advanced forecasting models
- Mobile app integration
- Barcode scanning
- Multi-language support
- Advanced analytics

## 📄 License

MIT License - Free to use and modify

## 💬 Support

For issues or questions:
1. Check the troubleshooting section
2. Review the code comments
3. Test with default credentials first

---

Made with ❤️ for SmartStock Inventory Management

"""
Populate SmartStock database with sample data from Excel/CSV
Usage: python scripts/populate_database.py
"""

import sys
import os
import pandas as pd
import sqlite3
from datetime import datetime

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

DB_PATH = "smartstock.db"

def populate_from_csv(csv_path):
    """Populate database from CSV file"""
    print(f"📂 Loading data from {csv_path}...")
    
    try:
        # Read CSV/Excel file
        if csv_path.endswith('.xlsx'):
            df = pd.read_excel(csv_path)
        else:
            df = pd.read_csv(csv_path)
        
        print(f"✅ Loaded {len(df)} records")
        
        # Handle missing values
        df = df.fillna({
            'city_id': 0,
            'city_name': '',
            'store_id': 0,
            'store_name': '',
            'product_id': 0,
            'product_name': '',
            'activity_flag': 0,
            'holiday_flag': 0,
            'stock_hour6_22_cnt': 0,
            'discount': 0,
            'sale_amount': 0
        })
        
        # Connect to database
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        
        # Insert cities
        print("📍 Inserting cities...")
        cities = df[['city_id', 'city_name']].drop_duplicates()
        for _, row in cities.iterrows():
            cur.execute(
                "INSERT OR IGNORE INTO city (cityid, cityname) VALUES (?, ?)",
                (int(row['city_id']), str(row['city_name']))
            )
        print(f"   Added {len(cities)} cities")
        
        # Insert products
        print("📦 Inserting products...")
        products = df[['product_id', 'product_name']].drop_duplicates()
        for _, row in products.iterrows():
            cur.execute(
                "INSERT OR IGNORE INTO product (productid, productname) VALUES (?, ?)",
                (int(row['product_id']), str(row['product_name']))
            )
        print(f"   Added {len(products)} products")
        
        # Insert stores
        print("🏪 Inserting stores...")
        stores = df[['store_id', 'store_name', 'city_id']].drop_duplicates()
        for _, row in stores.iterrows():
            cur.execute(
                """INSERT OR IGNORE INTO store 
                   (storeid, storename, store_manager, manager_email, password_hash, cityid)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    int(row['store_id']),
                    str(row['store_name']),
                    f"mgr_{int(row['store_id'])}",
                    f"manager{int(row['store_id'])}@smartstock.com",
                    "pbkdf2:sha256:260000$default$hash",  # Default password: "password"
                    int(row['city_id'])
                )
            )
        print(f"   Added {len(stores)} stores")
        
        # Insert sales records
        print("💰 Inserting sales records...")
        count = 0
        for _, row in df.iterrows():
            try:
                dt = pd.to_datetime(row['dt']) if 'dt' in row else datetime.now()
                cur.execute("""
                    INSERT INTO sales
                    (dt, cityid, storeid, productid, sale_amount, stock, hour, discount, holiday_flag, activity_flag)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    dt.strftime("%Y-%m-%d %H:%M:%S"),
                    int(row['city_id']),
                    int(row['store_id']),
                    int(row['product_id']),
                    int(row['sale_amount']),
                    int(row['stock_hour6_22_cnt']),
                    dt.hour if 'dt' in row else 0,
                    int(row['discount']),
                    int(row['holiday_flag']),
                    int(row['activity_flag'])
                ))
                count += 1
                
                if count % 1000 == 0:
                    print(f"   Processed {count} records...")
                    conn.commit()
            except Exception as e:
                print(f"   Error on row {count}: {e}")
                continue
        
        conn.commit()
        print(f"✅ Added {count} sales records")
        
        conn.close()
        print("\n✅ Database populated successfully!")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False
    
    return True

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python scripts/populate_database.py <path_to_csv_or_excel>")
        print("Example: python scripts/populate_database.py data/retail_data.xlsx")
        sys.exit(1)
    
    csv_path = sys.argv[1]
    
    if not os.path.exists(csv_path):
        print(f"❌ File not found: {csv_path}")
        sys.exit(1)
    
    populate_from_csv(csv_path)
